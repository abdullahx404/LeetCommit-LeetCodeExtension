var M=Object.defineProperty;var A=(e,t,n)=>t in e?M(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var m=(e,t,n)=>A(e,typeof t!="symbol"?t+"":t,n);import{e as D,n as q,g as I}from"./parser-X6j_64om.js";function L(){const e=`
    (function() {
      if (window.__gitleet_injected__) return;
      window.__gitleet_injected__ = true;

      const origFetch = window.fetch;
      window.fetch = async function(...args) {
        const response = await origFetch.apply(this, args);
        const clone = response.clone();

        try {
          const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');
          
          // Check GraphQL queries or submission polling routes
          if (url.includes('/submissions/detail/') || url.includes('/graphql') || url.includes('/submit/')) {
            clone.json().then(data => {
              if (!data) return;

              let isAccepted = false;
              let lang = '';
              let code = '';
              let probSlug = '';

              // Route 1: Standard REST polling check
              if (data.state === 'SUCCESS' && data.status_msg === 'Accepted') {
                isAccepted = true;
                lang = data.lang || '';
                code = data.code || '';
              }

              // Route 2: GraphQL submission details
              if (data.data && data.data.submissionDetails) {
                const sub = data.data.submissionDetails;
                if (sub.statusDisplay === 'Accepted' || sub.statusCode === 10) {
                  isAccepted = true;
                  lang = sub.lang && sub.lang.name ? sub.lang.name : (sub.lang || '');
                  code = sub.code || '';
                }
              }

              if (isAccepted) {
                window.postMessage({
                  type: 'GITLEET_SUBMISSION_ACCEPTED',
                  payload: {
                    language: lang,
                    code: code,
                    timestamp: Date.now()
                  }
                }, '*');
              }
            }).catch(() => {});
          }
        } catch (err) {}

        return response;
      };

      const origXhrOpen = XMLHttpRequest.prototype.open;
      const origXhrSend = XMLHttpRequest.prototype.send;

      XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this._url = url;
        return origXhrOpen.call(this, method, url, ...rest);
      };

      XMLHttpRequest.prototype.send = function(...args) {
        this.addEventListener('load', function() {
          try {
            if (this._url && (this._url.includes('/submissions/detail/') || this._url.includes('/graphql'))) {
              const text = this.responseText;
              if (text && text.includes('Accepted')) {
                const data = JSON.parse(text);
                if ((data.state === 'SUCCESS' && data.status_msg === 'Accepted') ||
                    (data.data && data.data.submissionDetails && data.data.submissionDetails.statusDisplay === 'Accepted')) {
                  window.postMessage({
                    type: 'GITLEET_SUBMISSION_ACCEPTED',
                    payload: { timestamp: Date.now() }
                  }, '*');
                }
              }
            }
          } catch (e) {}
        });
        return origXhrSend.apply(this, args);
      };
    })();
  `,t=document.createElement("script");t.textContent=e,(document.head||document.documentElement).appendChild(t),t.remove()}class u{static injectStyles(){if(document.getElementById("gitleet-pill-styles"))return;const t=document.createElement("style");t.id="gitleet-pill-styles",t.textContent=`
      :root {
        --pill-height: 48px;
        --icon-size: 24px;
      }

      @keyframes gitleet-popup-sequence {
        0% {
          opacity: 0;
          width: 48px;
          transform: scale(0.5);
        }
        8% {
          opacity: 1;
          width: 48px;
          transform: scale(1);
        }
        15%, 85% {
          width: 160px;
          opacity: 1;
          transform: scale(1);
        }
        92% {
          width: 48px;
          opacity: 1;
          transform: scale(1);
        }
        100% {
          opacity: 0;
          width: 48px;
          transform: scale(0.5);
        }
      }

      @keyframes gitleet-text-fade {
        0%, 12% {
          opacity: 0;
        }
        18%, 82% {
          opacity: 1;
        }
        88%, 100% {
          opacity: 0;
        }
      }
    `,document.head.appendChild(t)}static initContainer(){if(this.injectStyles(),this.container&&document.body.contains(this.container))return this.container;const t=document.createElement("div");return t.id="gitleet-toast-container",t.style.cssText=`
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 999999;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `,document.body.appendChild(t),this.container=t,t}static renderPill(t,n,a){const s=this.initContainer();this.activeToastEl&&(this.activeToastEl.remove(),this.activeToastEl=null);const i=document.createElement("div");i.className="notification-pill",i.style.cssText=`
      display: flex;
      align-items: center;
      height: 48px;
      background-color: ${n};
      color: #ffffff;
      border-radius: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      overflow: hidden;
      white-space: nowrap;
      animation: gitleet-popup-sequence 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
      pointer-events: auto;
    `;const o=document.createElement("div");o.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      flex-shrink: 0;
    `,o.innerHTML=a;const c=document.createElement("span");c.style.cssText=`
      font-size: 16px;
      font-weight: 600;
      padding-right: 20px;
      opacity: 0;
      animation: gitleet-text-fade 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    `,c.textContent=t,i.appendChild(o),i.appendChild(c),s.appendChild(i),this.activeToastEl=i,setTimeout(()=>{this.activeToastEl===i&&(i.remove(),this.activeToastEl=null)},4200)}static showUploading(t){this.renderPill("Syncing...","#3b82f6",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>')}static showSuccess(t){this.renderPill("Committed","#10b981",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>')}static showError(t){this.renderPill("Failed","#ef4444",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>')}}m(u,"container",null),m(u,"activeToastEl",null);let C=0,S="",v=0;const E=new Set;function j(){var n,a;try{const s=window;if((a=(n=s.monaco)==null?void 0:n.editor)!=null&&a.getModels){const o=s.monaco.editor.getModels()[0];if(o)return o.getValue()}}catch{}const e=document.querySelectorAll(".view-lines .view-line");if(e.length>0)return Array.from(e).map(s=>s.textContent||"").join(`
`);const t=document.querySelectorAll(".monaco-editor, code");for(let s=0;s<t.length;s++){const i=t[s];if(i){const o=i.textContent;if(o&&o.length>20&&!o.startsWith("Input:"))return o}}return"// Source code extraction failed"}function P(){const e=document.querySelector('meta[name="description"]');if(e){const n=e.getAttribute("content");if(n)return n}const t=document.querySelector('div[data-track-load="description_content"]');return t&&t.textContent?t.textContent.trim().slice(0,400):""}function B(e){var a,s,i;if(e)return e==="cpp"||e.toLowerCase()==="c++"?"C++":e==="python"||e==="python3"?"python3":e;try{const o=window;if((s=(a=o.monaco)==null?void 0:a.editor)!=null&&s.getModels){const c=o.monaco.editor.getModels();if(c[0]){const r=c[0].getLanguageId();return r==="cpp"?"C++":r==="python"?"python3":r==="java"?"Java":r==="typescript"?"TypeScript":r==="golang"||r==="go"?"Go":r==="rust"?"Rust":r==="csharp"?"C#":r}}}catch{}const t=["c++","python","python3","java","typescript","javascript","go","rust","c#","c","kotlin","swift","ruby","scala","php","dart"],n=document.querySelectorAll('[data-cy="lang-select"], [class*="lang-select"], button');for(let o=0;o<n.length;o++){const c=(((i=n[o])==null?void 0:i.textContent)||"").trim(),r=c.toLowerCase();if(t.includes(r))return r==="c++"?"C++":r==="python"||r==="python3"?"python3":c}return"C++"}function T(e,t){const n=window.location.pathname;let s=D(n).replace(/-/g," ").replace(/\b\w/g,l=>l.toUpperCase()),i="";const o=document.querySelector('h1, [data-cy="question-title"], .text-title-large');if(o&&o.textContent){const l=o.textContent.trim(),d=/^(\d+)\.\s*(.+)$/.exec(l);if(d){const w=d[1],b=d[2];w&&b&&(i=w,s=b.trim())}else s=l}let c="Medium";const r=document.querySelector('[class*="text-difficulty"], [data-difficulty], .text-olive, .text-yellow, .text-pink');r&&r.textContent&&(c=q(r.textContent));const p=B(t),f=e||j(),k=I(p),h=P();let g=f;if(h&&!f.includes("Problem:")){const l=p==="python3"||p==="Python"||p==="Ruby"?"#":"//",d=h.replace(/\r?\n+/g," ").slice(0,300);g=`${l} Problem: ${s}
${l} Description: ${d}...

${f}`}let y="0 ms",x="0 MB";return document.querySelectorAll(".text-label-1, .text-s, span").forEach(l=>{const d=l.textContent?l.textContent.trim():"";/^\d+\s*ms$/.test(d)&&(y=d),/^\d+(\.\d+)?\s*MB$/.test(d)&&(x=d)}),{problemTitle:s,problemNumber:i||"0000",difficulty:c,language:p,extension:k,sourceCode:g,timestamp:Date.now(),runtime:y,memory:x}}function _(e){const t=Date.now(),n=e.sourceCode.slice(0,100),a=`${e.problemTitle}:${n}`;E.has(a)||t-C<5e3&&S===n||(C=t,S=n,E.add(a),console.warn("Syncing accepted LeetCode submission to GitHub:",e.problemTitle),u.showUploading(e.problemTitle),chrome.runtime.sendMessage({type:"SUBMISSION_ACCEPTED",payload:e}).catch(()=>{u.showError("Extension background worker disconnected.")}))}chrome.runtime.onMessage.addListener(e=>{if(e&&typeof e=="object"&&"type"in e){const t=e;t.type==="GITLEET_SYNC_STATUS"&&t.payload&&(t.payload.status==="SUCCESS"?u.showSuccess(t.payload.title||"Solution"):t.payload.status==="ERROR"&&u.showError(t.payload.error||"Upload failed"))}});window.addEventListener("message",e=>{var n,a;if(e.source!==window||!e.data||typeof e.data!="object")return;const t=e.data;if(t.type==="GITLEET_SUBMISSION_ACCEPTED"){const s=T((n=t.payload)==null?void 0:n.code,(a=t.payload)==null?void 0:a.language);_(s)}});window.addEventListener("click",e=>{var n;const t=e.target;t&&((n=t.textContent)!=null&&n.includes("Submit")||t.closest('[data-e2e-locator="console-submit-button"]'))&&(v=Date.now())});const R=new MutationObserver(()=>{if(Date.now()-v>15e3)return;const e=document.querySelector('[data-e2e-locator="submission-result"], [class*="status-accepted"], .text-green-s');if(e&&e.textContent&&e.textContent.includes("Accepted")){const t=T();_(t)}});document.body&&R.observe(document.body,{childList:!0,subtree:!0});L();
