var j=Object.defineProperty;var q=(t,e,n)=>e in t?j(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n;var h=(t,e,n)=>q(t,typeof e!="symbol"?e+"":e,n);import{e as A,n as D,g as H}from"./parser-CN0C_U20.js";import"./injected.ts-Ds0wGPGX.js";class d{static initContainer(){if(this.container&&document.body&&document.body.contains(this.container))return this.container;const e=document.createElement("div");return e.id="gitleet-toast-container",e.style.position="fixed",document.body&&document.body.appendChild(e),this.container=e,e}static renderPill(e,n,s){const o=this.initContainer();if(!o)return;this.activeToastEl&&(this.activeToastEl.remove(),this.activeToastEl=null);const r=document.createElement("div");r.className="notification-pill",r.style.cssText=`
      display: flex;
      align-items: center;
      height: 48px;
      background-color: ${n};
      color: #ffffff;
      border-radius: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      overflow: hidden;
      white-space: nowrap;
      animation: gitleet-popup-sequence 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
      pointer-events: auto;
    `;const i=document.createElement("div");i.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      flex-shrink: 0;
    `,i.innerHTML=s;const l=document.createElement("span");l.style.cssText=`
      font-size: 16px;
      font-weight: 600;
      padding-right: 20px;
      opacity: 0;
      animation: gitleet-text-fade 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    `,l.textContent=e,r.appendChild(i),r.appendChild(l),o.appendChild(r),this.activeToastEl=r,setTimeout(()=>{this.activeToastEl===r&&(r.remove(),this.activeToastEl=null)},4200)}static showUploading(e){this.renderPill("Syncing...","#3b82f6",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>')}static showSuccess(e){this.renderPill("Committed","#10b981",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>')}static showError(e){this.renderPill("Failed","#ef4444",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>')}}h(d,"container",null),h(d,"activeToastEl",null);let S=0,T="",M="",$=0;const k=new Set;function U(){var n,s;try{const o=window;if((s=(n=o.monaco)==null?void 0:n.editor)!=null&&s.getModels){const i=o.monaco.editor.getModels()[0];if(i)return i.getValue()}}catch{}const t=document.querySelectorAll(".view-lines .view-line");if(t.length>0)return Array.from(t).map(o=>o.textContent||"").join(`
`);const e=document.querySelectorAll(".monaco-editor, code");for(let o=0;o<e.length;o++){const r=e[o];if(r){const i=r.textContent;if(i&&i.length>20&&!i.startsWith("Input:"))return i}}return"// Source code extraction failed"}function F(t,e){let n="";const s=document.querySelector('div[data-track-load="description_content"], .content__u3I1, [class*="_1l1ma"]');if(s)n=s.innerHTML;else{const i=document.querySelector('meta[name="description"]');n=i&&i.getAttribute("content")||""}let o=n.replace(/<pre[^>]*>(.*?)<\/pre>/igs,(i,l)=>{let c=l.replace(/<br\s*\/?>/ig,`
`).replace(/<\/(?:p|div|li)>/ig,`
`).replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/ig,"**$1**").replace(/<code[^>]*>(.*?)<\/code>/ig,"`$1`").replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");return c=c.replace(/(?:\*\*)?(Input|Output|Explanation)(?:\*\*)?\s*:/ig,`
**$1:**`).trim(),`

`+c.split(`
`).map(m=>m.trim()).filter(Boolean).join(`

`)+`

`}).replace(/<br\s*\/?>/ig,`
`).replace(/<\/(?:p|div|ul|ol|h[1-6])>/ig,`

`).replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/ig,"**$1**").replace(/<code[^>]*>(.*?)<\/code>/ig,"`$1`").replace(/<li[^>]*>(.*?)<\/li>/ig,`- $1
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&").replace(/(Example\s+\d+)\s*:/ig,`

**$1:**

`).replace(/(Constraints)\s*:/ig,`

**$1:**

`).replace(/(?:\*\*)?(Input|Output|Explanation)(?:\*\*)?\s*:/ig,`

**$1:**`).replace(/\n{3,}/g,`

`).trim();return o||(o="Problem description not available."),`# ${e?`${Number(e)}. `:""}${t}

## Problem Statement

${o}
`}function G(t){var s,o,r;if(t)return t==="cpp"||t.toLowerCase()==="c++"?"C++":t==="python"||t==="python3"?"python3":t;try{const i=window;if((o=(s=i.monaco)==null?void 0:s.editor)!=null&&o.getModels){const l=i.monaco.editor.getModels();if(l[0]){const c=l[0].getLanguageId();return c==="cpp"?"C++":c==="python"?"python3":c==="java"?"Java":c==="typescript"?"TypeScript":c==="golang"||c==="go"?"Go":c==="rust"?"Rust":c==="csharp"?"C#":c}}}catch{}const e=["c++","python","python3","java","typescript","javascript","go","rust","c#","c","kotlin","swift","ruby","scala","php","dart"],n=document.querySelectorAll('[data-cy="lang-select"], [class*="lang-select"], button');for(let i=0;i<n.length;i++){const l=(((r=n[i])==null?void 0:r.textContent)||"").trim(),c=l.toLowerCase();if(e.includes(c))return c==="c++"?"C++":c==="python"||c==="python3"?"python3":l}return"C++"}function B(t,e){var w,C;const n=window.location.pathname,s=A(n);let o=s.replace(/-/g," ").replace(/\b\w/g,a=>a.toUpperCase()),r="";const i=document.querySelector('h1, [data-cy="question-title"], .text-title-large');if(i&&i.textContent){const a=i.textContent.trim(),y=/^(\d+)\.\s*(.+)$/.exec(a);if(y){const v=y[1],E=y[2];v&&E&&(r=v,o=E.trim())}else o=a}if(!r&&document.title){const a=/^(\d+)\.\s*(.+?)\s*-\s*LeetCode/i.exec(document.title);a&&a[1]&&a[2]&&(r=a[1],o=a[2].trim())}let l="Medium";const c=document.querySelector('[class*="text-difficulty"], [data-difficulty], .text-olive, .text-yellow, .text-pink, [class*="difficulty"]');if(c&&c.textContent)l=D(c.textContent);else{const a=((w=document.body)==null?void 0:w.innerText)||"";/\bEasy\b/.test(a)&&!/\bMedium\b/.test(a)&&!/\bHard\b/.test(a)?l="Easy":/\bHard\b/.test(a)&&!/\bEasy\b/.test(a)&&!/\bMedium\b/.test(a)&&(l="Hard")}(r==="1"||o.toLowerCase()==="two sum"||s==="two-sum")&&(r="1",o="Two Sum",l="Easy");const p=G(e),m=t||U(),I=H(p),_=F(o,r);let b="0 ms",x="0 MB";const u=((C=document.body)==null?void 0:C.innerText)||"",f=/(?:runtime|time)\s*[:\n]?\s*(\d+)\s*ms/i.exec(u)||/\b(\d+)\s*ms\b/.exec(u);f&&f[1]&&(b=`${f[1]} ms`);const g=/(?:memory|space)\s*[:\n]?\s*(\d+(?:\.\d+)?)\s*MB/i.exec(u)||/\b(\d+(?:\.\d+)?)\s*MB\b/.exec(u);return g&&g[1]&&(x=`${g[1]} MB`),{problemTitle:o,problemNumber:r||"0000",difficulty:l,language:p,extension:I,sourceCode:m,timestamp:Date.now(),runtime:b,memory:x,readmeContent:_}}function L(t){var o;const e=Date.now(),n=t.sourceCode.slice(0,100),s=`${t.problemTitle}:${n}`;if(!k.has(s)&&!(e-S<1e4&&(M===t.problemTitle||T===n))){if(S=e,M=t.problemTitle,T=n,k.add(s),!((o=chrome==null?void 0:chrome.runtime)!=null&&o.id)){d.showError("Extension reloaded! Please refresh this page (F5) to sync.");return}console.warn("Syncing accepted LeetCode submission to GitHub:",t.problemTitle),d.showUploading(t.problemTitle);try{chrome.runtime.sendMessage({type:"SUBMISSION_ACCEPTED",payload:t}).catch(()=>{d.showError("Extension reloaded! Please refresh this page (F5) to sync.")})}catch{d.showError("Extension reloaded! Please refresh this page (F5) to sync.")}}}var P;(P=chrome==null?void 0:chrome.runtime)!=null&&P.id&&chrome.runtime.onMessage.addListener(t=>{if(t&&typeof t=="object"&&"type"in t){const e=t;e.type==="GITLEET_SYNC_STATUS"&&e.payload&&(e.payload.status==="SUCCESS"||e.payload.status==="SKIPPED"?(console.warn(`GitLeet sync confirmed (${e.payload.status}):`,e.payload.title),d.showSuccess(e.payload.title||"Solution")):e.payload.status==="ERROR"&&(console.warn("GitLeet sync failed:",e.payload.error),d.showError(e.payload.error||"Upload failed")))}});window.addEventListener("message",t=>{var n,s;if(t.source!==window||!t.data||typeof t.data!="object")return;const e=t.data;if(e.type==="GITLEET_SUBMISSION_ACCEPTED"){const o=B((n=e.payload)==null?void 0:n.code,(s=e.payload)==null?void 0:s.language);L(o)}});window.addEventListener("click",t=>{var s;const e=t.target;if(!e)return;const n=e.closest('button, [role="button"]');n&&(((s=n.textContent)==null?void 0:s.trim())==="Submit"||n.getAttribute("data-e2e-locator")==="console-submit-button")&&($=Date.now())});const N=new MutationObserver(()=>{if(Date.now()-$>15e3)return;const t=document.querySelector('[data-e2e-locator="submission-result"], [class*="status-accepted"], .text-green-s');t&&t.textContent&&t.textContent.includes("Accepted")&&setTimeout(()=>{const e=B();L(e)},1200)});document.body&&N.observe(document.body,{childList:!0,subtree:!0});
