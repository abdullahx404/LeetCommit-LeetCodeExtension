var _=Object.defineProperty;var A=(e,t,r)=>t in e?_(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var w=(e,t,r)=>A(e,typeof t!="symbol"?t+"":t,r);import{e as D,n as H,g as I}from"./parser-CN0C_U20.js";import"./injected.ts-CPTPtMSA.js";class p{static initContainer(){if(this.container&&document.body&&document.body.contains(this.container))return this.container;const t=document.createElement("div");return t.id="leetcommit-toast-container",t.style.position="fixed",document.body&&document.body.appendChild(t),this.container=t,t}static renderPill(t,r,i){const n=this.initContainer();if(!n)return;this.activeToastEl&&(this.activeToastEl.remove(),this.activeToastEl=null);const o=document.createElement("div");o.className="notification-pill",o.style.cssText=`
      display: flex;
      align-items: center;
      height: 48px;
      background-color: ${r};
      color: #ffffff;
      border-radius: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      overflow: hidden;
      white-space: nowrap;
      animation: leetcommit-popup-sequence 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
      pointer-events: auto;
    `;const l=document.createElement("div");l.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      flex-shrink: 0;
    `,l.innerHTML=i;const s=document.createElement("span");s.style.cssText=`
      font-size: 16px;
      font-weight: 600;
      padding-right: 20px;
      opacity: 0;
      animation: leetcommit-text-fade 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    `,s.textContent=t,o.appendChild(l),o.appendChild(s),n.appendChild(o),this.activeToastEl=o,setTimeout(()=>{this.activeToastEl===o&&(o.remove(),this.activeToastEl=null)},4200)}static showUploading(t){this.renderPill("Syncing...","#3b82f6",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>')}static showSuccess(t){this.renderPill("Committed","#10b981",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>')}static showError(t){this.renderPill("Failed","#ef4444",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>')}}w(p,"container",null),w(p,"activeToastEl",null);let M=0,P="",k="",j=0;const $=new Set;function U(){var o,l;try{const s=window;if((l=(o=s.monaco)==null?void 0:o.editor)!=null&&l.getModels){const c=s.monaco.editor.getModels()[0];if(c)return c.getValue()}}catch{}const e=document.querySelectorAll(".view-lines .view-line");if(e.length>0)return Array.from(e).map(s=>s.textContent||"").join(`
`);const t=document.querySelectorAll(".monaco-editor, code");for(let s=0;s<t.length;s++){const f=t[s];if(f){const c=f.textContent;if(c&&c.length>20&&!c.startsWith("Input:"))return c}}const r=document.querySelectorAll(".view-lines .view-line");if(r.length>0)return Array.from(r).map(s=>s.textContent||"").join(`
`);const i=document.querySelector(".CodeMirror");if(i&&i.CodeMirror)return i.CodeMirror.getValue();const n=document.querySelector('textarea.inputarea, textarea[class*="code"]');return n&&n.value?n.value:"// Solution code could not be automatically extracted."}function F(e,t,r){let i="";const n=document.querySelector('div[data-track-load="description_content"], .content__u3I1, [class*="_1l1ma"]');if(n)i=n.innerHTML;else{const c=document.querySelector('meta[name="description"]');i=c&&c.getAttribute("content")||""}let o=i.replace(/<sup[^>]*>(.*?)<\/sup>/igs,"^$1").replace(/<(?:em|i)[^>]*>(.*?)<\/(?:em|i)>/igs,"*$1*").replace(/<pre[^>]*>(.*?)<\/pre>/igs,(c,b)=>`

`+b.replace(/<br\s*\/?>/ig,`
`).replace(/<\/(?:p|div|li)>/ig,`
`).replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/ig,"**$1**").replace(/<code[^>]*>(.*?)<\/code>/ig,"`$1`").replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&").split(`
`).map(d=>d.trim()).filter(d=>!!d&&d!=="**"&&d!=="****").map(d=>{const u=/^(?:(?:\*\*|strong|b|\s)*)?(Input|Output|Explanation)(?:(?:\*\*|strong|b|\s)*)?\s*:?\s*(.*)/i.exec(d);if(u&&u[1]&&u[2]!==void 0){const y=u[1].charAt(0).toUpperCase()+u[1].slice(1).toLowerCase(),m=u[2].replace(/`/g,"").trim(),h=m?` \`${m}\``:"";return`**${y}:**${h}`}return d}).map(d=>d.startsWith(">")?d:`> ${d}`).join(`
> 
`)+`

`).replace(/<br\s*\/?>/ig,`
`).replace(/<\/(?:p|div|ul|ol|h[1-6])>/ig,`

`).replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/ig,"**$1**").replace(/<code[^>]*>(.*?)<\/code>/ig,"`$1`").replace(/<li[^>]*>(.*?)<\/li>/ig,`

* $1

`).replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");o=o.replace(/`+/g,"`").replace(/`\s*`([^`]+)`\s*`/g,"`$1`"),o=o.replace(/(?:\*\*|###\s*)?(Example\s+\d+|Constraints|Follow-up)(?:\*\*)?\s*:/ig,`

### $1:

`).replace(/\*\*\s*\*\*/g,""),o=o.split(`
`).map(c=>c.trim()).filter(c=>c!=="**"&&c!=="****"&&c!=="`"&&c!=="``"&&c!=="*").join(`
`).replace(/\n{3,}/g,`

`).trim(),o||(o="Problem description not available.");const s=t?`${Number(t)}. `:"",f=r?`\`${r}\`

`:"";return`# ${s}${e}

${f}${o}
`}function J(e){var r,i;if(e){if(e==="cpp"||e.toLowerCase()==="c++")return"C++";if(e==="java")return"Java";if(e==="python"||e==="python3")return"Python";if(e==="c")return"C";if(e==="csharp"||e==="cs")return"C#";if(e==="javascript"||e==="js")return"JavaScript";if(e==="typescript"||e==="ts")return"TypeScript";if(e==="php")return"PHP";if(e==="swift")return"Swift";if(e==="kotlin"||e==="kt")return"Kotlin";if(e==="dart")return"Dart";if(e==="golang"||e==="go")return"Go";if(e==="ruby"||e==="rb")return"Ruby";if(e==="scala")return"Scala";if(e==="rust"||e==="rs")return"Rust";if(e==="racket")return"Racket";if(e==="erlang")return"Erlang";if(e==="elixir")return"Elixir"}try{const n=window;if((i=(r=n.monaco)==null?void 0:r.editor)!=null&&i.getModels){const o=n.monaco.editor.getModels();if(o[0]){const l=o[0].getLanguageId();return l==="cpp"?"C++":l==="python"?"Python":l==="java"?"Java":l==="typescript"?"TypeScript":l==="golang"||l==="go"?"Go":l==="rust"?"Rust":l==="csharp"?"C#":l}}}catch{}const t=document.querySelector('button[id*="headlessui-listbox-button"], [data-cy="lang-select"], .select-button, [class*="lang-select"]');if(t&&t.textContent){const n=t.textContent.trim();if(n.includes("C++"))return"C++";if(n.includes("Java")&&!n.includes("Script"))return"Java";if(n.includes("Python"))return"Python";if(n==="C")return"C";if(n.includes("C#"))return"C#";if(n.includes("JavaScript"))return"JavaScript";if(n.includes("TypeScript"))return"TypeScript";if(n.includes("PHP"))return"PHP";if(n.includes("Swift"))return"Swift";if(n.includes("Kotlin"))return"Kotlin";if(n.includes("Dart"))return"Dart";if(n.includes("Go"))return"Go";if(n.includes("Ruby"))return"Ruby";if(n.includes("Scala"))return"Scala";if(n.includes("Rust"))return"Rust";if(n.includes("Racket"))return"Racket";if(n.includes("Erlang"))return"Erlang";if(n.includes("Elixir"))return"Elixir"}return"Code"}function q(e,t){var h,S;const r=window.location.pathname,i=D(r);let n=i.replace(/-/g," ").replace(/\b\w/g,a=>a.toUpperCase()),o="";const l=document.querySelector('h1, [data-cy="question-title"], .text-title-large');if(l&&l.textContent){const a=l.textContent.trim(),x=/^(\d+)\.\s*(.+)$/.exec(a);if(x){const E=x[1],T=x[2];E&&T&&(o=E,n=T.trim())}else n=a}if(!o&&document.title){const a=/^(\d+)\.\s*(.+?)\s*-\s*LeetCode/i.exec(document.title);a&&a[1]&&a[2]&&(o=a[1],n=a[2].trim())}let s="Medium";const f=document.querySelector('[class*="text-difficulty"], [data-difficulty], .text-olive, .text-yellow, .text-pink, [class*="difficulty"]');if(f&&f.textContent)s=H(f.textContent);else{const a=((h=document.body)==null?void 0:h.innerText)||"";/\bEasy\b/.test(a)&&!/\bMedium\b/.test(a)&&!/\bHard\b/.test(a)?s="Easy":/\bHard\b/.test(a)&&!/\bEasy\b/.test(a)&&!/\bMedium\b/.test(a)&&(s="Hard")}(o==="1"||n.toLowerCase()==="two sum"||i==="two-sum")&&(o="1",n="Two Sum",s="Easy");const c=J(t),b=e||U(),C=I(c),v=F(n,o,s);let g="0 ms",d="0 MB";const u=((S=document.body)==null?void 0:S.innerText)||"",y=/(?:runtime|time)\s*[:\n]?\s*(\d+)\s*ms/i.exec(u)||/\b(\d+)\s*ms\b/.exec(u);y&&y[1]&&(g=`${y[1]} ms`);const m=/(?:memory|space)\s*[:\n]?\s*(\d+(?:\.\d+)?)\s*MB/i.exec(u)||/\b(\d+(?:\.\d+)?)\s*MB\b/.exec(u);return m&&m[1]&&(d=`${m[1]} MB`),{problemTitle:n,problemNumber:o||"0000",difficulty:s,language:c,extension:C,sourceCode:b,timestamp:Date.now(),runtime:g,memory:d,readmeContent:v}}function R(e){var n;const t=Date.now(),r=e.sourceCode.slice(0,100),i=`${e.problemTitle}:${r}`;if(!$.has(i)&&!(t-M<1e4&&(k===e.problemTitle||P===r))){if(M=t,k=e.problemTitle,P=r,$.add(i),!((n=chrome==null?void 0:chrome.runtime)!=null&&n.id)){p.showError("Extension reloaded! Please refresh this page (F5) to sync.");return}console.warn("Syncing accepted LeetCode submission to GitHub:",e.problemTitle),p.showUploading(e.problemTitle);try{chrome.runtime.sendMessage({type:"SUBMISSION_ACCEPTED",payload:e}).catch(()=>{p.showError("Extension reloaded! Please refresh this page (F5) to sync.")})}catch{p.showError("Extension reloaded! Please refresh this page (F5) to sync.")}}}var B;(B=chrome==null?void 0:chrome.runtime)!=null&&B.id&&chrome.runtime.onMessage.addListener(e=>{if(e&&typeof e=="object"&&"type"in e){const t=e;t.type==="LEETCOMMIT_SYNC_STATUS"&&t.payload&&(t.payload.status==="SUCCESS"||t.payload.status==="SKIPPED"?(console.warn(`LeetCommit sync confirmed (${t.payload.status}):`,t.payload.title),p.showSuccess(t.payload.title||"Solution")):t.payload.status==="ERROR"&&(console.warn("LeetCommit sync failed:",t.payload.error),p.showError(t.payload.error||"Upload failed")))}});window.addEventListener("message",e=>{var r,i;if(e.source!==window||!e.data||typeof e.data!="object")return;const t=e.data;if(t.type==="LEETCOMMIT_SUBMISSION_ACCEPTED"){const n=q((r=t.payload)==null?void 0:r.code,(i=t.payload)==null?void 0:i.language);R(n)}});window.addEventListener("click",e=>{var i;const t=e.target;if(!t)return;const r=t.closest('button, [role="button"]');r&&(((i=r.textContent)==null?void 0:i.trim())==="Submit"||r.getAttribute("data-e2e-locator")==="console-submit-button")&&(j=Date.now())});const O=new MutationObserver(()=>{if(Date.now()-j>15e3)return;const e=document.querySelector('[data-e2e-locator="submission-result"], [class*="status-accepted"], .text-green-s');e&&e.textContent&&e.textContent.includes("Accepted")&&setTimeout(()=>{const t=q();R(t)},1200)});document.body&&O.observe(document.body,{childList:!0,subtree:!0});
